import postcss from 'postcss'

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
}